Credits
=======

Thanks to Stephen North and the AT&T Graphviz team for creating
and maintaining the Graphviz graph layout and drawing packages

Thanks to Manos Renieris for the original idea.

Thanks to the following people who have made contributions:

 - Cyril Brulebois helped clean up the packaging for Debian and find bugs. 

 - Rene Hogendoorn developed the threads code to provide nonblocking,
   multiplatform IO.

 - Ross Richardson suggested fixes and tested the attribute handling. 

 - Alexis Dinno debugged the setup and installation for OSX.

 - Stefano Costa reported attribute bugs and contributed the 
   code to run Graphviz "tred" and friends.

 - Casey Deccio contributed unicode handling design and code.

