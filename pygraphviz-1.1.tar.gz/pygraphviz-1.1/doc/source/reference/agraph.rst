.. _agraph:

************
AGraph Class
************

.. currentmodule:: pygraphviz

.. autoclass:: AGraph
   :members:
   :undoc-members:
