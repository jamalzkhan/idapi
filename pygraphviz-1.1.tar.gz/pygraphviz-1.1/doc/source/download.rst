--------
Download
--------

Source and Binary Releases
~~~~~~~~~~~~~~~~~~~~~~~~~~

http://cheeseshop.python.org/pypi/pygraphviz/

http://networkx.lanl.gov/download/pygraphviz/


Subversion Source Code Repository
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*Anonymous*          

svn checkout http://networkx.lanl.gov/svn/pygraphviz/trunk pygraphviz

*Authenticated* 

svn checkout https://networkx.lanl.gov/svn/pygraphviz/trunk pygraphviz

Documentation
~~~~~~~~~~~~~

*PDF*

http://networkx.lanl.gov/pygraphviz/pygraphviz.pdf

*HTML in zip file*

http://networkx.lanl.gov/pygraphviz/pygraphviz-documentation.zip
